console.log("hola mundo")
var a=1;
var b=2;
var r=a+b;
console.log("resultado :" + r);
console.log("hello word")
var d=2;
var e=5;
var t=d*e;
console.log("el resultado es: "+ t)

console.log("Raíz cuadra con funcion")
var j=1244;
var f=Math.sqrt(j);
console.log("el resultado es:" + f)

console.log("numeros primos 500.000")
